package com.stc.filemanager;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FilemanagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
